configYamlPath = "./configs/"  
datasetDir = "./dataset/"
saveLocation = "./plots/"